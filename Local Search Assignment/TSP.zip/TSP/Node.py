class Node:

    def __init__(self, label):
        self.label = label
        self.neighbours = {}

    def __str__(self):
        return self.__label
