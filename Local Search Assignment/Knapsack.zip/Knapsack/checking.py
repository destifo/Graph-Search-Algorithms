import random
import re
import copy

# variables for number of lines and for the maximum weight limit
read = open("hillclimb.txt", 'r')
len_line = read.readlines()
linelength = len(len_line)
read = open("hillclimb.txt", 'r')
maxcapacity = int(read.readlines(1)[0])


def readfile(file):
    # reading from file
    read = open(file, 'r')

    # jumping the 1st 2 lines
    read.readlines(1)
    read.readlines(1)

    container = read.read()
    # split the string on commas and new lines
    inter = re.split(pattern=r"[,\n]", string=container)
    dict = {}

    # for looping purpose
    i = 0

    while i < (
            linelength - 2) * 3 - 2:  # 3 for number of items per line , the first 2 for the first 2 unused line and the last 2 for keeping i in range
        dict[inter[i]] = (int(inter[i + 1]), int(inter[i + 2]))
        i += 3

    return dict


dict = readfile("hillclimb.txt")


# a function to randomly generate initial solution

def initializelist(dict):
    list1 = [random.randint(0, 1) for number in range(linelength - 2)]
    while True:
        sum = 0
        index = 0
        for key in dict:
            sum += dict[key][0] * list1[index]
            index += 1
        # checks if the proposed list satisfies the max weight constraint

        if (sum < 1000):
            break
        else:
            list1 = [random.randint(0, 1) for number in range(linelength - 2)]
            
    return list1

# a function to calculate total weight
def totalweight(list, dict):
    weight = 0
    index = 0
    for key in dict:
        weight += dict[key][0] * list[index]
        index += 1
    return weight

# a function to calculate total cost
def totalcost(list, dict):
    value = 0
    index = 0
    for key in dict:
        value += dict[key][1] * list[index]
        index += 1
    return value

# creates neighbours of a state
def neihbourgenerator(list):
    currentlist = list
    # a list containing all possible neighbours
    grandlist = []
    # checks if a neighbour is already visited or nor
    visted = []

    for j in range(0, len(currentlist)):
        # shallow copy of the list
        copylist = copy.copy(currentlist)

        # flip a single bit for each neighbour
        for i in range(j, len(currentlist)):
            # if bit equals 0 flip to 1
            if (copylist[i] == 0):
                copylist[i] = 1
                break
            # if bit equals 1 flip to 0
            else:
                copylist[i] = 0
                break
        grandlist.append(copylist)

    # evaluate each neighbour for utility
    for i in range(0, len(list)):

        # change state to a neighbour with the highest utility if such neighbour exists
        if (totalweight(grandlist[i], dict) <= maxcapacity and totalcost(grandlist[i], dict) > totalcost(list, dict)
                and grandlist[i] not in visted):
            currentlist = grandlist[i]
            visted.append(grandlist[i])
            return currentlist
        else:
            visted.append(grandlist[i])
            continue

# a function that checks if any better neighbour exist and return the best neighbour
def hillclimbing(mylist):
    while (True):
        # no better neighbour found
        if (neihbourgenerator(mylist) == None):
            return mylist
        else:
            mylist = neihbourgenerator(mylist)


# a function to convert the bit string to original items
def finalitems(list, dict):
    bestcombination=[]
    index=0
    for key in dict:
        if(list[index]==1):
            bestcombination.append(key)
            index+=1
        else:
            index+=1
    return bestcombination


finallist=hillclimbing(initializelist(dict))
print(finallist)
print(totalcost(finallist, dict))
print(finalitems(finallist,dict))
print(len(finallist), len(dict))
