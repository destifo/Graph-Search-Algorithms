

from fileinput import filename


filename = ""
fh = input(filename)

